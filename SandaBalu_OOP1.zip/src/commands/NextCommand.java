package commands;

public final class NextCommand extends Command {

}
