package commands;

public final class GetTop5SongsCommand extends Command {

}
