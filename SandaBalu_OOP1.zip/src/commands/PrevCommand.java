package commands;

public final class PrevCommand extends Command {

}
