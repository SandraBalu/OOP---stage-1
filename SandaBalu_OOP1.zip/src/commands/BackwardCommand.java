package commands;

public final class BackwardCommand extends Command {

}
