package commands;

public final class GetTop5PlaylistsCommand extends Command {

}
