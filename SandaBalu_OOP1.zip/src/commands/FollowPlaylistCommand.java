package commands;

public final class FollowPlaylistCommand extends Command {

}
