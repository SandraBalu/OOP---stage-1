package commands;

public final class ForwardCommand extends Command {

}
